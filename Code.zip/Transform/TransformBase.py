import os,json,ast
from PySide6.QtCore import QRectF,QPointF
from PySide6.QtGui import QPolygonF,QImage
from Database.DataOperate import DataOperate as DO
from Database.BaseModel import *

class TransformBase:
    def __init__(self) -> None:
        """"""


    def labelToDict(self, label:str) -> dict:
        """将label字符串转换为dict类型"""
        try:
            return ast.literal_eval(label)
        except Exception:
            return []

    def transformYolo(self,labelStr:str,width:int,height:int,labelDict:dict,isRect:bool)->str:
        """
        转换为yolo格式
        """
        errorInfo:dict={}

        if(width<0):
            width=-width
        if(height<0):
            height=-height

        labelArr=self.labelToDict(labelStr)
        labelStr=""
        for labelObj in labelArr:
            if labelObj["type"]=="LabelRectItem" and isRect:
                rectParts=labelObj["rect"].split(",")
                rect = QRectF(float(rectParts[0]), float(rectParts[1]), float(rectParts[2]), float(rectParts[3]))
                centerX=round(rect.center().x()/width,6)
                centerY=round(rect.center().y()/height,6)
                w=round(rect.width()/width,6)
                h=round(rect.height()/height,6)
                if w<0:
                    w=-w
                if h<0:
                    h=-h
                if labelObj["label_id"] in labelDict.keys():
                    labelStr=labelStr+str(labelDict[labelObj["label_id"]])+" "+str(centerX)+" "+str(centerY)+" "+str(w)+" "+str(h)+"\n"
                else:
                    errorInfo["error"]="label_id not found in labelDict"
            
            elif labelObj["type"]=="LabelRectItem" and not isRect:
                # 将矩形转为多边形
                rectParts=labelObj["rect"].split(",")
                rect = QRectF(float(rectParts[0]), float(rectParts[1]), float(rectParts[2]), float(rectParts[3]))
                polygonStr=""
                polygonStr+=str(round(rect.left()/width,6))+" "+str(round(rect.top()/height,6))+" "
                polygonStr+=str(round(rect.right()/width,6))+" "+str(round(rect.top()/height,6))+" "
                polygonStr+=str(round(rect.right()/width,6))+" "+str(round(rect.bottom()/height,6))+" "
                polygonStr+=str(round(rect.left()/width,6))+" "+str(round(rect.bottom()/height,6))+" "
                polygonStr=polygonStr[:-1]
                if labelObj["label_id"] in labelDict.keys():
                    labelStr=labelStr+str(labelDict[labelObj["label_id"]])+" "+polygonStr+"\n"
                else:
                    errorInfo["error"]="label_id not found in labelDict"
        
            elif labelObj["type"]=="LabelPolygonItem" and isRect:
                # 将多边形转为外接矩形
                polygonParts = labelObj["polygon"].split(",")
                polygonlist = [QPointF(float(polygonParts[i]), float(polygonParts[i + 1])) for i in range(0, len(polygonParts), 2)]
                polygonF=QPolygonF(polygonlist)

                boundingRect=polygonF.boundingRect()
                centerX=round(boundingRect.center().x()/width,6)
                centerY=round(boundingRect.center().y()/height,6)
                w=round(boundingRect.width()/width,6)
                h=round(boundingRect.height()/height,6)

                if labelObj["label_id"] in labelDict.keys():
                    labelStr=labelStr+str(labelDict[labelObj["label_id"]])+" "+str(centerX)+" "+str(centerY)+" "+str(w)+" "+str(h)+"\n"
                else:
                    errorInfo["error"]="label_id not found in labelDict"
            elif labelObj["type"]=="LabelPolygonItem" and not isRect:
                # 多边形标注
                polygonParts = labelObj["polygon"].split(",")
                polygon = [QPointF(float(polygonParts[i]), float(polygonParts[i + 1])) for i in range(0, len(polygonParts), 2)]

                polygonStr=""
                for point in polygon:
                    polygonStr+=str(round(point.x()/width,6))+" "+str(round(point.y()/height,6))+" "
                polygonStr=polygonStr[:-1]
                if labelObj["label_id"] in labelDict.keys():
                    labelStr=labelStr+str(labelDict[labelObj["label_id"]])+" "+polygonStr+"\n"
                else:
                    errorInfo["error"]="label_id not found in labelDict"
        
        return labelStr,errorInfo

    def splitImage(self,imagePath:str,labelStr:str,splitSize:int)->list[QImage]:
        """
        切分图片
        """
        labelArr=self.labelToDict(labelStr)
        imgList:list[QImage]=[]
        
        for labelObj in labelArr:
            splitW= splitSize
            splitH= splitSize
            if labelObj["type"]=="LabelRectItem" :
                rectParts=labelObj["rect"].split(",")
                rect = QRectF(float(rectParts[0]), float(rectParts[1]), float(rectParts[2]), float(rectParts[3]))

                if rect.width()>splitW:
                    splitW=rect.width()
                if rect.height()>splitH:
                    splitH=rect.height()
                center=rect.center()
                qimage=QImage(imagePath)
                qimage=qimage.copy(center.x()-splitW/2,center.y()-splitH/2,splitW,splitH)
                imgList.append(qimage)
            elif labelObj["type"]=="LabelPolygonItem":
                polygonParts = labelObj["polygon"].split(",")
                polygonlist = [QPointF(float(polygonParts[i]), float(polygonParts[i + 1])) for i in range(0, len(polygonParts), 2)]
                polygonF=QPolygonF(polygonlist)

                center=polygonF.boundingRect().center()

                if polygonF.boundingRect().width()>splitW:
                    splitW=polygonF.boundingRect().width()
                if polygonF.boundingRect().height()>splitH:
                    splitH=polygonF.boundingRect().height()

                qimage=QImage(imagePath)
                qimage=qimage.copy(center.x()-splitW/2,center.y()-splitH/2,splitW,splitH)
                imgList.append(qimage)
            
        return imgList
    
    def transformYoloSplit(self,labelStr:str,splitSize:int,labelDict:dict,isRect:bool)->list[str]:
        """
        转换为分割图格式
        """
        errorInfo:dict={}
        splitW= splitSize
        splitH= splitSize
        labelStrArr:list[str]=[]
        labelArr=self.labelToDict(labelStr)
        for i,labelObj in enumerate(labelArr):
            if labelObj["type"]=="LabelRectItem" and isRect:
                rectParts=labelObj["rect"].split(",")
                rect = QRectF(float(rectParts[0]), float(rectParts[1]), float(rectParts[2]), float(rectParts[3]))
                center=rect.center()
                if rect.width()>splitW:
                    splitW=rect.width()
                if rect.height()>splitH:
                    splitH=rect.height()
                leftTop=QPointF(center.x()-splitW/2,center.y()-splitH/2)
                rectStr=str(round((center.x()-leftTop.x())/splitW,6))+" "+str(round((center.y()-leftTop.y())/splitH,6))+" "+str(round(rect.width()/splitW,6))+" "+str(round(rect.height()/splitH,6))+"\n"

                if labelObj["label_id"] in labelDict.keys():
                    labelStr=str(labelDict[labelObj["label_id"]])+" "+rectStr
                    labelStr=labelStr.replace("-","")
                    labelStrArr.append(labelStr)
                else:
                    errorInfo["error"]="label_id not found in labelDict"
            elif labelObj["type"]=="LabelRectItem" and not isRect:
                # 将矩形转为多边形
                rectParts=labelObj["rect"].split(",")
                rect = QRectF(float(rectParts[0]), float(rectParts[1]), float(rectParts[2]), float(rectParts[3]))
                center=rect.center()
                if rect.width()>splitW:
                    splitW=rect.width()
                if rect.height()>splitH:
                    splitH=rect.height()
                leftTop=QPointF(center.x()-splitW/2,center.y()-splitH/2)
                polygonStr=""
                polygonStr+=str(round((rect.left()-leftTop.x())/splitW,6))+" "+str(round((rect.top()-leftTop.y())/splitH,6))+" "
                polygonStr+=str(round((rect.right()-leftTop.x())/splitW,6))+" "+str(round((rect.top()-leftTop.y())/splitH,6))+" "
                polygonStr+=str(round((rect.right()-leftTop.x())/splitW,6))+" "+str(round((rect.bottom()-leftTop.y())/splitH,6))+" "
                polygonStr+=str(round((rect.left()-leftTop.x())/splitW,6))+" "+str(round((rect.bottom()-leftTop.y())/splitH,6))+" "
                polygonStr=polygonStr[:-1]
                if labelObj["label_id"] in labelDict.keys():
                    labelStr=str(labelDict[labelObj["label_id"]])+" "+polygonStr+"\n"
                    labelStr=labelStr.replace("-","")
                    labelStrArr.append(labelStr)
                else:
                    errorInfo["error"]="label_id not found in labelDict"

            elif labelObj["type"]=="LabelPolygonItem" and isRect:
                # 将多边形转为外接矩形
                polygonParts = labelObj["polygon"].split(",")
                polygonlist = [QPointF(float(polygonParts[i]), float(polygonParts[i + 1])) for i in range(0, len(polygonParts), 2)]
                polygonF=QPolygonF(polygonlist)

                boundingRect=polygonF.boundingRect()
                center=boundingRect.center()
                if boundingRect.width()>splitW:
                    splitW=boundingRect.width()
                if boundingRect.height()>splitH:
                    splitH=boundingRect.height()

                leftTop=QPointF(center.x()-splitW/2,center.y()-splitH/2)

                rectStr=str(round((center.x()-leftTop.x())/splitW,6))+" "+str(round((center.y()-leftTop.y())/splitH,6))+" "+str(round(boundingRect.width()/splitW,6))+" "+str(round(boundingRect.height()/splitH,6))+"\n"

                if labelObj["label_id"] in labelDict.keys():
                    labelStr=str(labelDict[labelObj["label_id"]])+" "+rectStr
                    labelStr=labelStr.replace("-","")
                    labelStrArr.append(labelStr)
                else:
                    errorInfo["error"]="label_id not found in labelDict"

            elif labelObj["type"]=="LabelPolygonItem" and not isRect:
                polygonParts = labelObj["polygon"].split(",")
                polygonlist = [QPointF(float(polygonParts[i]), float(polygonParts[i + 1])) for i in range(0, len(polygonParts), 2)]
                polygonF=QPolygonF(polygonlist)
                center=polygonF.boundingRect().center()
                if polygonF.boundingRect().width()>splitW:
                    splitW=polygonF.boundingRect().width()
                if polygonF.boundingRect().height()>splitH:
                    splitH=polygonF.boundingRect().height()

                leftTop=QPointF(center.x()-splitW/2,center.y()-splitH/2)

                polygonStr=""
                for point in polygonlist:
                    polygonStr+=str(round((point.x()-leftTop.x())/splitW,6))+" "+str(round((point.y()-leftTop.y())/splitH,6))+" "
                polygonStr=polygonStr[:-1]

                if labelObj["label_id"] in labelDict.keys():
                    labelStr=str(labelDict[labelObj["label_id"]])+" "+polygonStr+"\n"
                    labelStr=labelStr.replace("-","")
                    labelStrArr.append(labelStr)
                else:
                    errorInfo["error"]="label_id not found in labelDict"

        return labelStrArr,errorInfo
    
    def transfromToLabels(self,originArr:dict,projectID:str)->str:
        """
        将labelme标注的数据EfficientSan(accuracy)转换为labelStr格式
        """
        labelDict:dict={}
        labellist:list[LabelData]=DO.query_label(project_id=projectID)
        labelDict= {label.name:label.id  for label in labellist}

        resArr:list[dict]=[]
        for item in originArr:
            if item["shape_type"]=="rectangle":
                labelName=item["label"]
                rectDict={}
                
                if labelName not in labelDict.keys():
                    labelData=LabelData()
                    labelData.name=labelName
                    labelData.color="#36e1ff"
                    labelData.project=projectID
                    labelData=DO.insert_label(labelData)
                    labelDict[labelName]=labelData.id
                    labelID=labelData.id
                else:
                    labelID=labelDict[labelName]
                x= item["points"][0][0]
                y= item["points"][0][1]
                width= abs(item["points"][1][0]-x)
                height= abs(item["points"][1][1]-y)

                rectDict["type"]="LabelRectItem"
                rectDict["label_id"]=labelID
                rectDict["rect"]=f"{x},{y},{width},{height}"
                resArr.append(rectDict)
            elif item["shape_type"]=="polygon":
                labelName=item["label"]
                polygonDict={}
                
                if labelName not in labelDict.keys():
                    labelData=LabelData()
                    labelData.name=labelName
                    labelData.color="#36e1ff"
                    labelData.project=projectID
                    labelData=DO.insert_label(labelData)
                    labelDict[labelName]=labelData.id
                    labelID=labelData.id
                else:
                    labelID=labelDict[labelName]
                
                points=item["points"]
                polygonStr=""
                for point in points:
                    polygonStr+=str(point[0])+","+str(point[1])+","
                polygonStr=polygonStr[:-1]

                polygonDict["type"]="LabelPolygonItem"
                polygonDict["label_id"]=labelID
                polygonDict["polygon"]=polygonStr
                resArr.append(polygonDict)
        
        return str(resArr)